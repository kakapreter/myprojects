var config = {
    /*在这里配置你的基本信息，所有数据以字符串形式给出*/
    name: "徐彦枫",
    sex: "男",
    age: "23",
    phone: "18239028167",
    email: "3110479275@qq.com",
    address: "现居北京市通州区",
    qq: "3110479275",
    log: "kakapreter",
    excpect_work: "Java后端开发",


    /*在这里配置首页的座右铭集合*/
    motto: [
        "那些过去的眼泪终将风干在记忆里。",
		"有志者,事竟成,破釜沉舟,百二秦关终属楚。",
	    "苦心人,天不负,卧薪尝胆,三千越甲可吞吴。"
    ],


    /*在这里配置首页的见面信息，你可以内嵌HTML标签以调整格式*/
    welcome: "青青子衿，悠悠我心<br>" +
             "但为君故，沉吟至今<br>" +
             "你好，我是徐彦枫，吉林建筑科技学院大四在读<br>" +
             "很高兴见到你!",


    /*在这里配置关于我的信息，你可以内嵌HTML标签以调整格式*/
    about: "<p>你好！我叫徐彦枫，性别男，吉林建筑科技学院大四在读。我期望的工作岗位是Java后端开发。</p>" +
        "<p>我有着较多的Java编程经验，计算机基础知识掌握扎实，能够在工作中很好的完成自己的任务。此外，我有着充满激情的工作态度，团队协同作战能力强，同时我也具备独立开发的能力，擅于发现并解决问题。我的执行力强、责任感高、集体荣誉感强、敢于担当，能够接受加班或出差等安排。</p>" +
        "<p>十分期待与您的联系!</p>",



    /** 
    * 在这里配置你的技能点
    * ["技能点", 掌握程度, "技能条颜色"]
    */  
    skills: [
        ["Java", 80, "red"],
        ["SQL", 75, "#1abc9c"],
        ["HTML5", 67, "rgba(0,0,0)"],
        ["CSS3", 60, "yellow"],
        ["JavaScript", 70, "pink"]
    ],


    /*这里填写你的技能描述，你可以内嵌HTML标签以调整格式*/
    skills_description: "<ul>" +	
        "     <li><a href='https://blog.csdn.net/Royalic/article/details/119999404' style='color:yellow' target='_blank'>操作系统</a>、<a href='https://blog.csdn.net/Royalic/article/details/119985591' style='color:yellow' target='_blank'>计算机网络</a>等编程基础知识良好。</li>" +
        "     <li>熟练掌握<a href='https://blog.csdn.net/sen_sen97/article/details/125702448'  style='color:yellow' target='_blank'>Java基础</a>。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/weixin_43884234/article/details/116952152' style='color:yellow' target='_blank'>JavaIO</a>、<a href='https://blog.csdn.net/Evankaka/article/details/44153709' style='color:yellow' target='_blank'>多线程</a>、<a href='https://blog.csdn.net/zdl66/article/details/126251818' style='color:yellow' target='_blank'>集合</a>等基础框架。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/promsing/article/details/112793260' style='color:yellow' target='_blank'>SQL语句</a>编写以及<a href='https://blog.csdn.net/SQY0809/article/details/115254620' style='color:yellow' target='_blank'>调优</a>。</li>" +
        "     <li>熟悉基本<a href='http://linux.51yip.com/' style='color:yellow' target='_blank'>Linux命令</a>操作。</li>" +
        "     <li>熟悉HTML、CSS、<a href='https://yanhaijing.com/basejs/' style='color:yellow' target='_blank'>JavaScript</a>、<a href='https://blog.csdn.net/weixin_42371679/article/details/112408800' style='color:yellow' target='_blank'>Vue</a>以及相应前端知识。</li>" +
	    "     <li>熟悉<a href='https://blog.csdn.net/qq_52797170/article/details/125549416' style='color:yellow' target='_blank'>Spring</a>、<a href='https://baomidou.com/' style='color:yellow' target='_blank'>Mybatis-Plus</a>、<a href='https://mybatisplusjoin.com/' style='color:yellow' target='_blank'>Mybatis-Plus-Join</a>、<a href='https://blog.csdn.net/cuiqwei/article/details/118188540' target='_blank' style='color:yellow' target='_blank'>SpringBoot</a>等框架的使用。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/u014723137/article/details/125658176' style='color:yellow' target='_blank'>Redis缓存</a>、<a href='https://blog.csdn.net/kavito/article/details/91403659' style='color:yellow' target='_blank'>RabbitMQ消息队列</a>等机制。</li>" +
        "     <li>了解<a href='https://segmentfault.com/a/1190000018626163' style='color:yellow' target='_blank'>分布式系统</a>的设计与应用。</li>" +
		"     <li>了解<a href='https://blog.csdn.net/weixin_45105261/article/details/110311485' style='color:yellow' target='_blank'>JVM原理</a>。</li>" +
        " </ul>",


    /**
     * 这里填写你的个人作品展示
     * ["img"，"url", "ProjectName", "brief"]
     * img表示您的作品图片链接，url表示您的项目地址，ProjectName表示您的仓库或作品名称，brief是一句简短的介绍
     * 通过查看实际效果以调整字题长度
     */
    portfolio: [
        ["./images/pro-1.png", "http://lenmanxv.xyz/", "个人网站", "这里记录着我收集的网站<br>"],
		["./images/pro-2.png", "https://www.52pojie.cn/thread-1797251-1-1.html", "吾爱破解虚拟机", "个人整合的Win7_X64位吾爱虚拟机<br>"],
		["./images/pro-3.png", "https://www.52pojie.cn/thread-1843262-1-1.html", "Typora0.9.98(beta) for Windows / Linux","个人整合的Typora 0.9.98版<br>"]
       ],


    /**
     * 这里填写您的工作经历
     * ["日期"， "工作"， "介绍"]
     * 你可以内嵌HTML标签以排版格式
     */
    work: [
        //如果您内有工作经历，您可以采取下列写法
        // ["————————", "", "<p>暂无工作经历，期待您的联系。</p>"]

		["2023-10-01 — 2023-11-02", "<br>谷粒学院<br>",
            "<p><strong>谷粒学院项目</strong></p>" +
            "<p>框架 : SpringBoot,SpringCloud,MybatisPlus,SpringMVC,Swagger 服务器 : Tomcat,Nginx 容器 : Docker</p>" +
			"<p>项目介绍 : 在线教育，是以网络为介质的教学方式，通过网络，学员与教师即使相隔万里也能开展教学活动。此外，借助网络课件，学员还可以随时随地进行学习，真正打破了时间和空间的限制。</p>"+
			"<p>负责模块 : 讲师模块接口开发（增删改查）</p>" + 
			"<p>习得技能点:</p>" + 
			"<p>1. 了解了统一结果返回类的设计及整合Swagger</p>" + 
			"<p>2. 了解了Nginx的负载均衡</p>" +
			"<p>3. 了解了跨域访问问题，阿里云的OSS服务</p>"
        ],
        ["2023-08-20 — 2023-09-28", "<br>畅购商城",
            "<p><strong>畅购商城项目</strong></p>" +
            "<p>框架 : SpringBoot,SpringCloud,Mybatis 服务器 : Tomcat,Nginx</p>" +
			"<p>项目介绍 : 此电商项目属于B2C模式的线上商城，支持用户在线浏览商品，在线搜索商品，并且可以将喜欢的商品加入购物车从而下单购买商品，同时支持线上支付，支付模式支持支付宝、微信、银联支付。用户还可以参与低价商品秒杀。</p>"+
			"<p>负责模块 : 秒杀微服务</p>" + 
			"<p>习得技能点:</p>" + 
			"<p>1. 了解了Nginx的限流思想</p>" + 
			"<p>2. 了解了多级缓存的重要性</p>" +
			"<p>3. 了解了RabbitMQ的异步通信优势 </p>" + 
			"<p>4. 了解了Redis的单线程设计的优势</p>"
		],
		["2023-07-10 — 2023-08-14", "<br>传智健康",
			"<p><strong>传智健康项目</strong></p>" +
            "<p>框架 : SpringBoot,Dubbo,SpringMVC ,Spring Security,Vue 服务器: Tomcat</p>" +
			"<p>项目介绍 : 传智健康管理系统是一款应用于健康管理机构的业务系统，实现健康管理机构工作内容可视化、会员管理专业化、健康评估数字化、健康干预流程化、知识库集成化，从而提高健康管理师的工作效率，加强与会员间的互动，增强管理者对健康管理机构运营情况的了解。</p>"+
			"<p>负责模块 : 预约管理模块开发（增删改查）</p>" + 
			"<p>习得技能点:</p>" + 
			"<p>1. 了解了Dubbo远程调用服务</p>" + 
			"<p>2. 了解了项目服务拆分的重要性</p>" +
			"<p>3. 了解了高可用高并发系统所面临的技术难题及分而治之的思想</p>" 

		]
		
    ],


    /**
     * 这里填写你的其他经历
     * ["日期"， "经历"， "介绍"]
     * 建议填写您的校级及以上得奖经历或或其他证书
     */	
    others: [
        ["2022-09-10——2022-10-30", "Java知识的学习——被搁置的蓝桥杯比赛", "  随着学习的深入,听很多人说都去<a href='https://leetcode.cn' style='color:yellow' target='_blank'>LeetCode</a>刷算法题,这时意识到了数据结构的重要性,又去认真学了一些数据结构，但是也没太多的深入,这段时间在B站上边看一些视频边刷一些算法题,说实话挺难的，没过多久就被难退了,之后就没再刷了。整理了一个数据结构的在线知识文档<a href='https://kakapreter.gitbook.io/structure/'  style='color:yellow' target='_blank'>structure</a>。这段时间内学了Java的很多知识,虽然是旧的知识,但是没过多久,B站上<a href='https://space.bilibili.com/37974444' target='_blank' style='color:yellow'>《黑马程序员》</a>出课程了,我感觉这Java课程设计的很硬核啊,就一直跟着这个课。至于这个比赛的事情就耽搁了。"],
        ["2021-09-05——2021-10-10", "  在校期间参加过《基于人工智能的医药分析系统》研发", "说实在的,当时第一次接触项目的研发,就像一只无头苍蝇到处乱撞,不知道如何下手。正是在这段时间内,我学习了各种类型的语言如Python,Java,C++,JavaScript,但都是些皮毛,当真正意识到一个项目不可能就是几个人就能完成的之后,当时我们就放弃了这个项目的研发。我们意识到必须要更深刻地学习其中一门语言。最终我决定选择Java,因为大数据给我推送的都是Java相关的内容,另外我也喜欢这门语言。但是我发现有另外一个跟Java类似的语言C#,但是我没认真学C#。"]
    ],


    /**
     * 在这里填写您的社交网络平台
     * ["img", "url", "desc"]
     * img是社交平台的图标，在./svg目录下我们已经准备好了 微博、简书、掘金、小红书、知乎、csdn、facebook、github、力扣、CF和qq的图标
     * url是您链接
     * desc是一段描述，将鼠标移入将会显示该描述
     * 建议您放置数量 <= 5
     */
    icon: [
        ["./svg/LeetCode.svg", "https://leetcode.cn/u/mp_len/", "我的力扣主页"],
        ["./svg/github.svg", "https://github.com/kakapreter", "我的GitHub主页"]
    ],


    //这是一些图片链接，建议您仅更改第二个头像图片
    url: [
        //背景图、头像、作品展示背景、其他经历背景
        "./images/intro-bg.jpg",
        "./images/2.jpg",
        "./images/work-bk.png",
        "./images/4.jpg"
    ]

}