var config = {
    /*在这里配置你的基本信息，所有数据以字符串形式给出*/
    name: "徐彦枫",
    sex: "男",
    age: "23",
    phone: "18239028167",
    email: "3110479275@qq.com",
    address: "现居北京市通州区",
    qq: "3110479275",
    log: "kakapreter",
    excpect_work: "Java后端开发",


    /*在这里配置首页的座右铭集合*/
    motto: [
        "那些过去的眼泪终将风干在记忆里。",
		"有志者,事竟成,破釜沉舟,百二秦关终属楚。",
	    "苦心人,天不负,卧薪尝胆,三千越甲可吞吴。"
    ],


    /*在这里配置首页的见面信息，你可以内嵌HTML标签以调整格式*/
    welcome: "青青子衿，悠悠我心<br>" +
             "但为君故，沉吟至今<br>" +
             "你好，我是徐彦枫，吉林建筑科技学院大四在读<br>" +
             "很高兴见到你!",


    /*在这里配置关于我的信息，你可以内嵌HTML标签以调整格式*/
    about: "<p>你好！我叫徐彦枫，性别男，吉林建筑科技学院大四在读。我期望的工作岗位是Java后端开发。</p>" +
        "<p>我有着较多的Java编程经验，计算机基础知识掌握扎实，能够在工作中很好的完成自己的任务。此外，我有着充满激情的工作态度，团队协同作战能力强，同时我也具备独立开发的能力，擅于发现并解决问题。我的执行力强、责任感高、集体荣誉感强、敢于担当，能够接受加班或出差等安排。</p>" +
        "<p>十分期待与您的联系!</p>",



    /** 
    * 在这里配置你的技能点
    * ["技能点", 掌握程度, "技能条颜色"]
    */  
    skills: [
        ["Java", 80, "red"],
        ["SQL", 75, "#1abc9c"],
        ["HTML5", 67, "rgba(0,0,0)"],
        ["CSS3", 60, "yellow"],
        ["JavaScript", 70, "pink"]
    ],


    /*这里填写你的技能描述，你可以内嵌HTML标签以调整格式*/
    skills_description: "<ul>" +	
        "     <li><a href='https://blog.csdn.net/Royalic/article/details/119999404' style='color:yellow' target='_blank'>操作系统</a>、<a href='https://blog.csdn.net/Royalic/article/details/119985591' style='color:yellow' target='_blank'>计算机网络</a>等编程基础知识良好。</li>" +
        "     <li>熟练掌握<a href='https://blog.csdn.net/sen_sen97/article/details/125702448'  style='color:yellow' target='_blank'>Java基础</a>。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/weixin_43884234/article/details/116952152' style='color:yellow' target='_blank'>JavaIO</a>、<a href='https://blog.csdn.net/Evankaka/article/details/44153709' style='color:yellow' target='_blank'>多线程</a>、<a href='https://blog.csdn.net/zdl66/article/details/126251818' style='color:yellow' target='_blank'>集合</a>等基础框架。</li>" +
        "     <li>了解<a href='https://blog.csdn.net/weixin_45105261/article/details/110311485' style='color:yellow' target='_blank'>JVM原理</a>。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/promsing/article/details/112793260' style='color:yellow' target='_blank'>SQL语句</a>编写以及<a href='https://www.modb.pro/db/225373' style='color:yellow' target='_blank'>调优</a>。</li>" +
        "     <li>熟悉基本<a href='http://linux.51yip.com/' style='color:yellow' target='_blank'>Linux命令</a>操作。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/qq_52797170/article/details/125549416' style='color:yellow' target='_blank'>Spring</a>、<a href='https://baomidou.com/' style='color:yellow' target='_blank'>mybatis-plus</a>、<a href='https://mybatisplusjoin.com/' style='color:yellow' target='_blank'>mybatis-plus-join</a>、<a href='https://blog.csdn.net/cuiqwei/article/details/118188540' target='_blank' style='color:yellow' target='_blank'>springboot</a>等框架的使用。</li>" +
        "     <li>熟悉<a href='https://blog.csdn.net/u014723137/article/details/125658176' style='color:yellow' target='_blank'>Redis缓存</a>、<a href='https://blog.csdn.net/kavito/article/details/91403659' style='color:yellow' target='_blank'>RabbitMQ消息队列</a>等机制。</li>" +
        "     <li>了解<a href='https://segmentfault.com/a/1190000018626163' style='color:yellow' target='_blank'>分布式系统</a>的设计与应用。</li>" +
        "     <li>熟悉HTML、CSS、<a href='https://yanhaijing.com/basejs/' style='color:yellow' target='_blank'>JavaScript</a>、<a href='https://blog.csdn.net/weixin_42371679/article/details/112408800' style='color:yellow' target='_blank'>Vue</a>以及相应前端知识。</li>" +
        " </ul>",


    /**
     * 这里填写你的个人作品展示
     * ["img"，"url", "ProjectName", "brief"]
     * img表示您的作品图片链接，url表示您的项目地址，ProjectName表示您的仓库或作品名称，brief是一句简短的介绍
     * 通过查看实际效果以调整字题长度
     */
    portfolio: [
        ["./images/pro-1.png", "http://lenmanxv.xyz/", "个人网站", "这里记录着我收集的网站<br>"],
		["./images/pro-2.png", "https://www.52pojie.cn/thread-1797251-1-1.html", "吾爱破解虚拟机", "个人整合的Win7_X64位吾爱虚拟机<br>"],
		["./images/pro-3.png", "https://www.52pojie.cn/thread-1843262-1-1.html", "Typora0.9.98(beta) for Windows / Linux","个人整合的Typora 0.9.98版<br>"]
       ],


    /**
     * 这里填写您的工作经历
     * ["日期"， "工作"， "介绍"]
     * 你可以内嵌HTML标签以排版格式
     */
    work: [
        //如果您内有工作经历，您可以采取下列写法
        // ["————————", "", "<p>暂无工作经历，期待您的联系。</p>"]

	
        ["2020-7-1 — 2021-8-10", "<br>阎王殿实习生",
            "<p><strong>阎王殿研发部</strong></p>" +
            "<p>随着阴历7月15中元节的到来，阎王殿的任务愈发庞大，我以及我所在小组主要负责阎王谱后台部分，拟在解决千万访问并发问题，经过不械努力，使得产品稳定、高效的运行。</p>" 
        ]
    ],


    /**
     * 这里填写你的其他经历
     * ["日期"， "经历"， "介绍"]
     * 建议填写您的校级及以上得奖经历或或其他证书
     */	
    others: [
        ["2023-11-08", "***", "***"],
        ["2023-07-05", "***", "***"]
    ],


    /**
     * 在这里填写您的社交网络平台
     * ["img", "url", "desc"]
     * img是社交平台的图标，在./svg目录下我们已经准备好了 微博、简书、掘金、小红书、知乎、csdn、facebook、github、力扣、CF和qq的图标
     * url是您链接
     * desc是一段描述，将鼠标移入将会显示该描述
     * 建议您放置数量 <= 5
     */
    icon: [
        ["./svg/LeetCode.svg", "https://leetcode.cn/u/mp_len/", "我的力扣主页"],
        ["./svg/github.svg", "https://github.com/kakapreter", "我的GitHub主页"]
    ],


    //这是一些图片链接，建议您仅更改第二个头像图片
    url: [
        //背景图、头像、作品展示背景、其他经历背景
        "./images/intro-bg.jpg",
        "./images/2.jpg",
        "./images/work-bk.png",
        "./images/4.jpg"
    ]

}